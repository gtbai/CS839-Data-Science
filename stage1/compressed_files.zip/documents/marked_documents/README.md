## Entity Type

Person names

## Marks

Person names are marked up using a pair of curly braces, i.e.`{person}`.

For a person name consisting of several parts, only the longest name will be marked.

**Example 1**

> When he meets {Marla} ({Helena Bonham Carter}), another fake attendee of support groups, his life seems to become a little more bearable. However when he associates himself with {Tyler} ({Brad Pitt}) he is dragged into an underground fight club and soap making scheme.

**Example 2**

> {William Wallace} is a Scottish rebel who leads an uprising against the cruel English ruler {Edward} the Longshanks, who wishes to inherit the crown of Scotland for himself. 

 